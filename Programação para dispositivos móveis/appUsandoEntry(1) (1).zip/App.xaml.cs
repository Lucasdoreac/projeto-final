﻿using appUsandoEntry.Views;
using Microsoft.Extensions.DependencyInjection;

namespace appUsandoEntry
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }

        protected override Window CreateWindow(IActivationState? activationState)
        {
            return new Window(new FlyoutPageMenu());
        }
    }
}