namespace appUsandoEntry.Views;

public partial class CadastroDeCarros : ContentPage
{
	public CadastroDeCarros()
	{
		InitializeComponent();
	}
}